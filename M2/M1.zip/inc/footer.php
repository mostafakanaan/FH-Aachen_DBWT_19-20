<hr> <!-- Trennlinie über Footer-->
        <footer class="row" class="footer">
            <div class="col-3 copyright">
                <i class="far fa-copyright"></i>
				DBWT
                <?php
                echo date("d.m.Y", time())
                ?>
            </div>
            <nav class="col-6" class="footer">
                <ul class="nav" id="bottom_nav">
                	<!-- die Deko-Striche evtl schöner -->
                    <li class="nav-item"><a class="nav-link" href="#">Login</a></li>
                    <li class="nav-item"><a class="nav-link" href="#">Registrieren</a></li>
                    <li class="nav-item"><a class="nav-link active" href="#">Zutatenliste</a></li>
                    <li class="nav-item"><a class="nav-link active" href="Impressum.php">Impressum</a></li>
                </ul>
            </nav>
        </footer>